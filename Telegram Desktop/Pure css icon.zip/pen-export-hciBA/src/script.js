/*
  - Code by Lior Amsalem
  - Icons Inspired by Nicolas Gallagher
  - Practice :before, :after, border-radius, transform, rotate
*/