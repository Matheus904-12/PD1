# Detailed Theme Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/OJazKey](https://codepen.io/jkantner/pen/OJazKey).

A theme toggle switch with extra illustrative detail. Based on a [Dribbble shot by Pixpowder](https://dribbble.com/shots/18924039-Toggle-UI-dark-light-animation).

⚠️ Firefox still has unstable support of `:has()` (which is used here) as of this Pen.