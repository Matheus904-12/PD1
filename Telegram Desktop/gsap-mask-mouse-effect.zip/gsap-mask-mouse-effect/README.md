# Gsap Mask Mouse Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/alig01/pen/WNLGogV](https://codepen.io/alig01/pen/WNLGogV).

https://greensock.com/forums/topic/38210-svg-cursor-content-mask/#comment-190387