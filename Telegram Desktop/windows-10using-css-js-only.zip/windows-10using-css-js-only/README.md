# Windows 10 - Using CSS & JS Only

A Pen created on CodePen.io. Original URL: [https://codepen.io/MohamedElGhandour/pen/GEbwEW](https://codepen.io/MohamedElGhandour/pen/GEbwEW).

