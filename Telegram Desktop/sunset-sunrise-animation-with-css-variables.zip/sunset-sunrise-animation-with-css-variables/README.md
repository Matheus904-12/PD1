# Sunset/Sunrise Animation with CSS Variables

A Pen created on CodePen.io. Original URL: [https://codepen.io/davidkpiano/pen/VmMWZW](https://codepen.io/davidkpiano/pen/VmMWZW).

Based on a [Dribbble](https://dribbble.com/shots/3114192-Sunset-Sunrise-Animation) by [Denys Boldyriev](https://dribbble.com/denisbldrv) and [Andrey Pixy](https://dribbble.com/anpixy).

Works only in Chrome (for now) because of the crazy things I'm doing with CSS variables.