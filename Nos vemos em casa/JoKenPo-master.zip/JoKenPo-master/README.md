## JoKenPo

Jogo Simples de Pedra-Papel-Tesoura com histórico de partidas

Página exemplo [AQUI!](https://festive-hopper-e74e65.netlify.app)
